import { Injectable } from '@angular/core';
import { Result, User } from './user.model';
import { HttpClient } from '@angular/common/http';

const N_USER_DISPLAYER = 20;

@Injectable({
  providedIn: 'root',
})
export class RubricaService {
  userList: User[] = [];

  constructor(private http: HttpClient) {
    this.getUserList()
    .then(r => this.userList = r)
    .catch(err => console.warn("Err"));

  }


  getUserList(): Promise<User[]> {
    return this.http
    .get<Result>('http://192.168.9.116:3000/api')
    .toPromise()
    .then((o) => {
      if (o != null && o.results != null) {
        return o.results;
      } else {
        return [];
      }
    });
  }

  getUser(id : string): Promise<User> {
    let user = this.userList.filter((u) => u.login?.uuid === id);
    if (user.length >= 1) {
      return Promise.resolve(user[0]);
    } else {
      return Promise.reject('User con id = ' + id + ' non trovato');
    }
  }
}
